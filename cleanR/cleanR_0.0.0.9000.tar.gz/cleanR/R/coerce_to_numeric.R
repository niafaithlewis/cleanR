#' Coerce Numeric Columns and Print Class Changes
#'
#' This function identifies columns expected to be numeric, detects values stored as text,
#' coerces them to numeric, and prints the changes in class and values.
#'
#' @param data A data frame containing the dataset.
#' @param numeric_columns A character vector of column names expected to be numeric.
#' @name coerce_numeric_columns
#' @return A data frame with specified columns coerced to numeric.
#' @examples
#' updated_data <- coerce_numeric_columns(plants_clean, numeric_columns = c("target_weight"))
#' @export
coerce_numeric_columns <- function(data, numeric_columns) {
  for (col in numeric_columns) {
    if (!col %in% colnames(data)) {
      warning(paste("Column", col, "not found in the dataset. Skipping."))
      next
    }
    
    # Extract column values as character for inspection
    raw_values <- as.character(data[[col]])
    
    # Attempt to coerce all values to numeric
    coerced_values <- suppressWarnings(as.numeric(raw_values))
    
    # Identify which values were coerced successfully
    is_problematic <- is.na(coerced_values) & !is.na(raw_values)
    problematic_values <- raw_values[is_problematic]
    
    if (length(problematic_values) > 0) {
      # Alert user about problematic values
      message(paste("Text-formatted numbers detected in column", col, ":"))
      print(data.frame(Observation = which(is_problematic), Value = problematic_values))
    }
    
    # Record original and new classes for each observation
    original_classes <- sapply(raw_values, class)
    new_classes <- ifelse(is.na(coerced_values), "NA", "numeric")
    
    # Print the class changes
    changes <- data.frame(
      Observation = seq_along(data[[col]]),
      Column = col,
      OriginalValue = raw_values,
      OriginalClass = original_classes,
      NewValue = coerced_values,
      NewClass = new_classes,
      stringsAsFactors = FALSE
    )
    print(changes)
    
    # Assign coerced values back to the column
    data[[col]] <- coerced_values
  }
  
  # Return the updated dataset
  return(data)
}




