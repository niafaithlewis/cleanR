
#' Identify and Visualize Potential Swaps in Longitudinal Weight Data
#'
#' This function identifies potential swaps where weights in earlier timepoints 
#' exceed weights in later timepoints and highlights those rows in a graph.
#' It returns the dataset with flags indicating potential swaps and a line graph for visualization.
#'
#' @param data A data frame containing the dataset.
#' @param weight_columns A character vector specifying the names of columns with weight data.
#' @param key_column A character string specifying the column name used to identify rows (e.g., "pot_id").
#' @param plot_filename A character string specifying the file name to save the plot (e.g., "swaps_plot.png").
#' @return A list containing:
#'   \item{swaps}{A data frame of rows flagged as potential swaps.}
#'   \item{plot}{A ggplot object visualizing the weights and flagged potential swaps.}
#'   \item{saved_plot}{The path to the saved image file.}
#' @import ggplot2
#' @importFrom dplyr %>%
#' @importFrom tidyr pivot_longer
#' @importFrom rlang sym 
#' @importFrom rlang !!
#' @name identify_and_plot_swaps
#' @export

library(ggplot2)
library(dplyr)
library(tidyr)
library(rlang)

identify_and_plot_swaps <- function(data, weight_columns, key_column, plot_filename = "/cloud/project/cleanR/inst/extdata/swaps_plot.png") {
  # Ensure required columns are present
  if (!all(c(weight_columns, key_column) %in% colnames(data))) {
    stop("Some specified columns are missing from the dataset.")
  }
  
  # Flag potential swaps where weight at an earlier timepoint exceeds weight at a later timepoint
  data$Flagged <- FALSE
  for (i in 1:(nrow(data) - 1)) {
    # Compare weights between the two columns (weight_columns)
    if (data[[weight_columns[1]]][i] > data[[weight_columns[2]]][i]) {
      data$Flagged[i] <- TRUE  # Flag if the weight order is invalid
      data$Flagged[i + 1] <- TRUE  # Flag the next row as well
    }
  }
  
  # Melt data for ggplot (long format)
  melted_data <- data %>%
    pivot_longer(cols = weight_columns, 
                 names_to = "Weight_Type", 
                 values_to = "Weight")
  
  # Create a line graph for each plant (x-axis is the weight types, y-axis is the weight)
  plot <- ggplot(melted_data, aes(x = !!sym("Weight_Type"), y = !!sym("Weight"), group = !!sym(key_column), color = as.factor(!!sym(key_column)))) +
    geom_line(alpha = 0.7) +
    geom_point(aes(shape = !!sym("Flagged")), size = 2) +
    scale_shape_manual(values = c(`TRUE` = 4, `FALSE` = 16)) +  # Flagged points as crosses
    theme_minimal() +
    labs(title = "Longitudinal Weight Data with Potential Swaps Highlighted",
         x = "Weight Type", y = "Weight", color = "Plant ID",
         shape = "Potential Swap") +
    theme(legend.position = "bottom")
  
  # Save the plot to the specified file path
  ggsave(plot_filename, plot = plot, width = 8, height = 6)
  
  # Return the flagged swaps and plot details
  list(swaps = data[data$Flagged == TRUE, ], plot = plot, saved_plot = plot_filename)
}


