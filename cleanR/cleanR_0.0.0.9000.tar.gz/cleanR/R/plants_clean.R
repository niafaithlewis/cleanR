#' Cleaned Plants Dataset
#'
#' A dataset containing cleaned data for plant treatments.
#'
#' @docType data
#' @name plants_clean
#' @usage data(plants_clean)
#' @format A data frame with 10 rows and 9 columns:
#' \describe{
#'   \item{treatment}{A factor indicating the treatment applied to the plant.}
#'   \item{pot_id}{A character string describing the plant type.}
#'   \item{line}{Numeric variable indicating the height of the plant (in cm).}
#'   \item{mom}{Numeric variable for leaf area (in cm²).}
#'   \item{dad}{Numeric variable indicating the growth rate of the plant.}
#'   \item{tray_id}{Numeric variable for leaf area (in cm²).}
#'  \item{target_weight}{Numeric variable for leaf area (in cm²).}
#'  \item{X10_6_weight}{Numeric variable for leaf area (in cm²).}
#'  \item{X10_9_weight}{Numeric variable for leaf area (in cm²).}
#'   }
#' @source Data generated from a controlled experiment in plant biology.

plants_clean <- read.csv("/cloud/project/cleanR/data-raw/plants_test.csv")
save(plants_clean, file = "/cloud/project/cleanR/data/plants_clean.rda")