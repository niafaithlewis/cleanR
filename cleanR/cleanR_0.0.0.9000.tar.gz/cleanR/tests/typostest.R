# Load the required packages
library(cleanR)

plants_clean <- read.csv("/cloud/project/cleanR/data-raw/plants_test.csv")

head(plants_clean)

potential_typos <- identify_typos(plants_clean$treatment)

print(potential_typos)

potential_typos <- identify_typos(c("d", "dry", "w", "wet", "d", "w", "dr", "d"))
print(potential_typos)

# Example with varied entries
potential_typos <- identify_typos(c("d", "d", "w", "dry", "wet", "dr", "d"))

print(potential_typos)


data <- c("d", "dry", "w", "wet", "d", "w", "dr", "d")
potential_typos <- identify_typos(data)
print(potential_typos)


