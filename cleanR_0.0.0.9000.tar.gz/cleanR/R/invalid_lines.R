#' Detect Invalid 'line' Values in a Dataset
#'
#' This function identifies rows in the dataset where the values in the `line` column
#' deviate from the expected pattern (i.e., "C1", "SC1", or "SI1"). It returns a 
#' data frame with the rows that contain invalid `line` values and suggests possible corrections.
#'
#' @param data A data frame containing the dataset.
#' @return A data frame with rows where the `line` column contains invalid values, along with suggested corrections.
#' @examples
#' # Example dataset
#' mousedata <- data.frame(
#'   treatment = c("d", "d", "d", "wet", "d", "w"),
#'   pot_id = c(1, 2, 3, 4, 5, 6),
#'   line = c("C1", "SXX1", "SC1", "SI1", "C1", "C1"),
#'   mom = c(86, 225, 231, 672, 2, 27),
#'   dad = c(59, 258, 245, 697, 44, 100),
#'   tray_id = c(1, 10, 1, 1, 1, 1),
#'   dry_weight = c(165, 168, 158, 170, 172, 160)
#' )
#' 
#' # Detect invalid 'line' values
#' invalid_lines <- detect_invalid_lines(mousedata)
#' print(invalid_lines)
#' 
#' @export
detect_invalid_lines <- function(data) {
  # Define the valid patterns for the 'line' column
  valid_patterns <- c("C1", "SC1", "SI1")
  
  # Regular expression for valid patterns
  valid_regex <- "^(C1|SC1|SI1)$"
  
  # Trim any whitespace from the 'line' column and ensure case insensitivity
  data$line <- trimws(data$line)  # Remove leading/trailing whitespace
  
  # Identify rows with invalid 'line' values (ignore case)
  invalid_entries <- data[!grepl(valid_regex, data$line, ignore.case = TRUE), ]
  
  # Suggest corrections using string distance
  if (nrow(invalid_entries) > 0) {
    message("The following rows contain invalid 'line' values:")
    invalid_entries$suggested_correction <- apply(invalid_entries, 1, function(row) {
      line_value <- row["line"]
      distances <- stringdist::stringdist(line_value, valid_patterns, method = "jw")
      closest_match <- valid_patterns[which.min(distances)]
      return(closest_match)
    })
    print(invalid_entries)
  } else {
    message("All 'line' values are valid.")
  }
  
  # Return the invalid entries with suggested corrections
  return(invalid_entries)
}
