#' Identify Possible Typos in Text Data (Improved Version)
#'
#' This function identifies potential typos based on a combination of string lengths 
#' and string distances using the stringdist package.
#'
#' @param data A character vector or a column of a dataframe containing text data.
#' @param length_threshold The length threshold for identifying typos. Words longer
#'   or shorter than this threshold are flagged as possible typos.
#' @param distance_threshold The string distance threshold to flag words that are 
#'   similar but not identical. Default is 0.2 (Jaro-Winkler distance).
#' @return A character vector with possible typos identified.
#' @export
#'
#' @examples
#' identify_typos(c("Placobo", "Plac", "Tmt", "Trmt", "wet", "dr", "dry"))
identify_typos <- function(data, length_threshold = 1, distance_threshold = 0.15) {
  # Ensure input is a character vector
  if (!is.character(data)) {
    stop("Input data must be a character vector.")
  }
  
  # Remove NAs and blank strings (including strings with only spaces)
  data <- data[!stringr::str_detect(data, "^\\s*$") & !is.na(data)]
  
  # If there are less than two strings left after filtering, return an empty result
  if (length(data) < 2) {
    message("Not enough valid data to identify typos.")
    return(data.frame(Original = character(0), Flagged = logical(0)))
  }
  
  # Calculate the length of each string
  lengths <- stringr::str_length(data)
  
  # Calculate the average string length
  avg_length <- mean(lengths)
  
  # Find the most frequent length (mode) - useful for flagging outliers
  mode_length <- as.numeric(names(sort(table(lengths), decreasing = TRUE)[1]))
  
  # Flag strings where the length deviates significantly from the average or mode length
  potential_typos_length <- abs(lengths - avg_length) > length_threshold | abs(lengths - mode_length) > length_threshold
  
  # Apply stringdist to compare each word with others (using Jaro-Winkler distance by default)
  dist_matrix <- stringdist::stringdistmatrix(data, data, method = "jw")  # Using Jaro-Winkler method
  
  # Consider a typo if the string distance is greater than the threshold with any other string
  potential_typos_distance <- apply(dist_matrix, 1, function(x) any(x < distance_threshold & x > 0))  # Exclude self-comparison
  
  # Combine the length and distance checks
  flagged <- potential_typos_length | potential_typos_distance
  
  # Prepare the result as a data frame
  potential_typos <- data.frame(
    Original = data,
    Flagged = flagged,
    stringsAsFactors = FALSE
  )
  
  # Print flagged rows for visibility
  flagged_rows <- potential_typos[potential_typos$Flagged, ]
  if (nrow(flagged_rows) > 0) {
    message("The following values were flagged as potential typos:")
    print(flagged_rows)
  } else {
    message("No typos detected.")
  }
  
  # Return the result as a data frame
  return(potential_typos)
}
