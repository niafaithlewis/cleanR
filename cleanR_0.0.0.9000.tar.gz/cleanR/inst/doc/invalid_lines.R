## -----------------------------------------------------------------------------
### Load package  
library(cleanR)

data("plants_clean")

head(plants_clean)

## -----------------------------------------------------------------------------
invalid_lines <- detect_invalid_lines(plants_clean)

