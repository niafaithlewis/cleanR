## -----------------------------------------------------------------------------
### Load library
library(cleanR)

plants_clean <- read.csv("/cloud/project/cleanR/data-raw/plants_test.csv")

head(plants_clean)

## -----------------------------------------------------------------------------
mean_weight <- mean("X10_9_weight")

class(plants_clean$X10_9_weight)

## -----------------------------------------------------------------------------
### Coerce the X10_9_weight column to numeric
updated_data <- coerce_numeric_columns(
  data = plants_clean, 
  numeric_columns = c("X10_9_weight")
)


## -----------------------------------------------------------------------------
### Print the updated data
print(updated_data)

## -----------------------------------------------------------------------------
mean_updated <- mean(updated_data$X10_9_weight)

print(mean_updated)

class(updated_data$X10_9_weight)

