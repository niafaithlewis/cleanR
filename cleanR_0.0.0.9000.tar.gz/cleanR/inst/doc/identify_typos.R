## -----------------------------------------------------------------------------
###Load libary 
library(cleanR)

# Sample data
plants_clean <- read.csv("/cloud/project/cleanR/data-raw/plants_test.csv")

# Preview the data
head(plants_clean)

## -----------------------------------------------------------------------------
# Identify typos in the 'treatment' column
potential_typos <- identify_typos(plants_clean$treatment)

# Print the result
print(potential_typos)

## -----------------------------------------------------------------------------
typos <- identify_typos(plants_clean$treatment, expected_values = c("w", "d"))

print(typos)

## -----------------------------------------------------------------------------
example_data <- c("dry", "dr", "d", "wet", "wet", "we", "wet", "dry", "dry")

###Apply function with expected values 
example_typos <- identify_typos(example_data, expected_values = c("wet", "dry"))

print(example_typos)


