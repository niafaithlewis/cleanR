## -----------------------------------------------------------------------------
### Load library
library(cleanR)

# Example dataset
plants_clean <- read.csv("/cloud/project/cleanR/data-raw/plants_test.csv")

# Preview the data
head(plants_clean)

## -----------------------------------------------------------------------------
# Apply the identify_and_plot_swaps function
swaps_output <- identify_and_plot_swaps(
  data = plants_clean,
  weight_columns = c("X10_6_weight", "X10_9_weight"),  # Specify weight columns
  key_column = "pot_id",  # Specify key column
  plot_filename = "swaps_plot.png",  # Specify plot filename
  weight_diff_threshold = 100  # Specify threshold for weight difference to flag swaps
)


# View the flagged swaps
print(swaps_output$swaps)

