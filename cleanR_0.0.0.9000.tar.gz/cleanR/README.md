
# cleanR

<!-- badges: start -->
<!-- badges: end -->

The goal of cleanR is to ...

## Installation

You can install the development version of cleanR like so:

``` r
# FILL THIS IN! HOW CAN PEOPLE INSTALL YOUR DEV PACKAGE?
```

## Example

This is a basic example which shows you how to solve a common problem:

``` r
library(cleanR)
## basic example code
```

